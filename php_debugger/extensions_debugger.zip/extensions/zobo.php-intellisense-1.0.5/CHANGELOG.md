# See [GitHub releases](https://github.com/zobo/vscode-php-intellisense/releases)
